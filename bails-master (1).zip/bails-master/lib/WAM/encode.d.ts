import { BinaryInfo } from './BinaryInfo'

export declare const encodeWAM: (binaryInfo: BinaryInfo) => Buffer